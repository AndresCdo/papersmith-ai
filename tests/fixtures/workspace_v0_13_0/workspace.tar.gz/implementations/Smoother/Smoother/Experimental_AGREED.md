# Agreed

- [ ] the first pass uses a fixed window of five observations (experimental-implementation)
## Ladder

<!-- position revision=experiments-smoothing-window-sweep-v01.md sha256=e0ab95884b0ae91eb8f1208f33f5c8a12fb4a99cc8651b83935d9aa6c388cdfd derivedAt=2026-10-12T08:11:09Z session=fixture target=local documents=W3sibGFiZWwiOiJwcm9wb3NhbCIsInJldmlzaW9uIjoicmVzZWFyY2gtY29uY2VwdC1zbW9vdGhpbmctZXN0aW1hdG9yLWZvci1ub2lzeS1zZXF1ZW5jZXMtcjAyLm1kIiwicmV2aXNpb25TaGEyNTYiOiI5YTc3MzcxYjVlODBmOTBiMGI1OGYyZWM4MWY0MWY1MjMwNTk5MGUyYmQ5Yjg5ZDU3YTQzYjRiYjM4OTZmNzZlIn1d -->
- [ ] 1. the verification notebook runs (experimental-implementation) `@notebook Notebooks/verification.ipynb`
<!-- /position -->
