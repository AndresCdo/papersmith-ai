# Agreed

- [ ] the first pass uses a fixed window of five observations (proposal-implementation)
## Ladder

<!-- position revision=research-concept-smoothing-estimator-for-noisy-sequences-r02.md sha256=9a77371b5e80f90b0b58f2ec81f41f52305990e2bd9b89d57a43b4bb3896f76e derivedAt=2026-10-12T08:11:09Z session=fixture target=local -->
- [ ] 1. the verification notebook runs (proposal-implementation) `@notebook Notebooks/verification.ipynb`
<!-- /position -->
