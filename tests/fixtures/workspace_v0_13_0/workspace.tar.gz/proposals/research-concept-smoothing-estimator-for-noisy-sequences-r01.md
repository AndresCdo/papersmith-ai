<!-- proposal-workspace:artifact:v1 -->
# Smoothing estimator for noisy sequences.

## We study a moving average estimator and bound its error.

Smoothing estimator for noisy sequences. We study a moving average estimator and bound its error.
