# Sample data

A generic synthetic sequence dataset with a fixed train and test split.
