# Fixture workspace

This paper workspace is managed by `papersmith` 0.13.0.

- **Project**: `workspace`
- **Research topic**: generic
- **Configuration**: `papersmith.yaml`
- **Proposals**: `proposals/`
- **Implementations**: `implementations/`
- **Reference literature**: `guidance/reference-papers/`
- **Execution drops**: `kaggle-inbox/`

Framework files are synchronized with `papersmith upgrade`; research
artifacts remain protected by the workspace preservation contract.
