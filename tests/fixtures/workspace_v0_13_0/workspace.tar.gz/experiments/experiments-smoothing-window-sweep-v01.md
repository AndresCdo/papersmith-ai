<!-- proposal-workspace:artifact:v1 -->
# Smoothing window sweep.

## Testing whether the window length changes the estimator error.

Smoothing window sweep. Testing whether the window length changes the estimator error. Claim C1: the error decreases with the window.

**Dataset:** sample-data (fixed train/test split).

**Validation scheme:** paired comparison, 3 seeds, 2 repetitions per seed.

## Reference Sources

### guidance/data-paper/sample-data/sample-data.md

# Sample data

A generic synthetic sequence dataset with a fixed train and test split.

### proposals/research-concept-smoothing-estimator-for-noisy-sequences-r01.md

<!-- proposal-workspace:artifact:v1 -->
# Smoothing estimator for noisy sequences.

## We study a moving average estimator and bound its error.

Smoothing estimator for noisy sequences. We study a moving average estimator and bound its error.

### proposals/research-concept-smoothing-estimator-for-noisy-sequences-r02.md

<!-- proposal-workspace:artifact:v1 -->
# Smoothing estimator for noisy sequences.

## We study a moving average estimator and bound its error.

The estimator averages a fixed window of past observations.

## Changes

**What:** Initial revision.

**Why:** First published version.
